<?php
session_start();
require_once("response.php");//include KooKoo library.This is available in the download
$r=new Response(); //create a response object
$cd = new CollectDtmf();
if($_REQUEST['event']=="NewCall") //when a new call comes...
{
        $_SESSION['cid']=$_REQUEST['cid'];
        //store details of caller and time in database if you want so you never miss a call
        //Update this with your own company name and your own prompt.
        $cd->addPlayText("Thank you for calling MY COMPANY. Please press 1 for sales, press 2 for support, press 3 for others");
		$r->addCollectDtmf($cd);
		$r->send();
}
else if($_REQUEST['event']=="GotDTMF") //once a user hangs up the call,do the following
{
	$selection=$_REQUEST['data'];
	if($selection == "1")
	{
		$r->addDial("9912343425");//enter your sales guys number
	}
	else if($selection == "2")
	{
		$r->addDial("9913421234");//enter your support guys number
	}
	else
	{
		$r->addDial("9953421234");//enter your default number
		//or do 
		//$r->addRecord($_SESSION['cid']); //to enable voice mail
	}
	$r->send();
}
else
{
	$r->addHangup();
	$r->send();
}
?>
